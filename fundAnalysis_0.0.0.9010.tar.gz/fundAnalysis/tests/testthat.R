library(testthat)
library(fundAnalysis)

test_check("fundAnalysis")
