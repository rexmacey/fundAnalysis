# fundAnalysis
Code to analyze and track mutual funds and ETFs.  Output should include: factor exposures, style analysis, performance both relative to a benchmark and absolute.
