## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "",
  echo = FALSE,
  warning = FALSE,
  message = FALSE
)

## ----initialize, echo=FALSE, message=FALSE-------------------------------
# User defined input goes here
fundSymbol <- "FNDE"
nbenchmark <- 2
runSections <- list(summary=TRUE, performance = TRUE, famaFrench = TRUE)


## ----loadLibraries, echo=FALSE-------------------------------------------
library(knitr)
library(MASS, quietly = TRUE)
library(quantmod, quietly = TRUE)
library(readr, quietly = TRUE)
library(rvest, quietly = TRUE)
library(xts, quietly = TRUE)
library(ggplot2, quietly = TRUE)
library(FactorAnalytics, quietly = TRUE)
library(fundAnalysis, quietly = TRUE)
library(PerformanceAnalytics, quietly = TRUE)

## ----getData-------------------------------------------------------------



## ----fundSummary, eval=runSections$summary-------------------------------
quoteSummary <- scrapeQuoteSummary(fundSymbol)
kable(quoteSummary, caption = "Basic information")    

