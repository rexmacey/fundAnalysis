# benchmark

symbol<-"FNDB"

p <- getPrices(symbol,startDate = "2012-12-31",freq = "D")
r <- convertPricesToReturns(p)

# r <- faCommonDate(r)
# temp<-matrix(unlist(r),ncol=length(r))
# temp1<-xts(temp,order.by = index(r[[1]]))
# colnames(temp1)<-names(r)
# temp2 <- t(apply(temp1,1,function(x) x*weights))
# temp2<-apply(temp2,1,sum)
# temp3 <- xts(temp2,order.by = index(temp1))

b1 <- defineBenchmark("SP500","S&P 500 ETF", "SPY", 1, startDate = "2005-12-31", freq="D")
b2 <- defineBenchmark("Bench","50% S&P 500 / 50% Barclay's Agg", c("SPY","AGG"), c(0.5,0.5), startDate = "2005-12-31", freq="D")


