## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----loadLibraries, echo=FALSE, message=FALSE----------------------------
library(MASS, quietly = TRUE)
library(quantmod, quietly = TRUE)
library(readr, quietly = TRUE)
library(rvest, quietly = TRUE)
library(xts, quietly = TRUE)
library(FactorAnalytics, quietly = TRUE)
library(fundAnalysis, quietly = TRUE)

## ----showSymbols---------------------------------------------------------
# Data is provided for the following symbols
print(symbols)

## ----retrieveFFData, cache=TRUE------------------------------------------
# ff_datam <- download_FF_5_factor("M")
# ff_datad <- download_FF_5_factor("D")

# Monthly Fama-French data
head(ff_datam)
tail(ff_datam)
# Daily Fama-French data
head(ff_datad)
tail(ff_datam)

## ----retrieveFundPrices, cache=TRUE--------------------------------------
#prices_d <- getPrices(symbols,startDate="2012-12-31", freq="D")
#prices_m <- getPrices(symbols,startDate="2012-12-31", freq="M")
# Daily prices for a few of the funds
head(prices_d)[,1:6]
tail(prices_d)[,1:6]
# Monthly prices for a few of the funds
head(prices_m)[,1:6]
tail(prices_m)[,1:6]

## ----convertPricesToReturns, cache=TRUE----------------------------------
# Daily returns of the funds - a list with one item per fund
# First fund
#rets_d <- convertPricesToReturns(prices_d, freq="D")
#rets_m <- convertPricesToReturns(prices_d, freq="M")
names(rets_d[1])
head(rets_d[[1]])
tail(rets_d[[1]])

## ----summaryInfo, cache=TRUE---------------------------------------------
#summary_data <- scrapeQuoteSummary(symbols)
# Information for an ETF
summary_data["FNDB"]
# Information for a mutual fund
summary_data["DFALX"]

## ----lmModels, warning=FALSE, comment="",message=FALSE-------------------
lm_listd <- ffModelLM(rets_d, ff_datad)

print.mdl_list <- function(lm_list){
    print("Summaries")
    for (i in 1:2){
        mdl <- lm_list[[i]]
        print(names(lm_list[i]))
        print(summary(mdl))
    }
}

print.mdl_list(lm_listd)
print(round(100*coefficients_lm(lm_listd),2))

## ---- stepModels, warning=FALSE, comment="", message=FALSE---------------
step_listd <- ffModelStepLM(rets_d,ff_datad)
print.mdl_list(lm_listd)
print(round(100*coefficients_step(step_listd),2))

## ----moreLMFunctions-----------------------------------------------------
mdl <- step_listd[[1]]
print("Model coefficients")
print(coefficients(mdl)) # just view the coefficients 
print("Confidence interval of the coefficients at a specified level")
print(confint(mdl,level=0.9)) # view the confidence interval of the coefficients
print("The fitted (predicted) values - only first few displayed")
print(head(fitted(mdl))) # show the fitted (predicted) values
print("The residuals (errors) - only first few displayed")
print(head(residuals(mdl)))  # show the residuals (errors)

## ----RBSA_entire window--------------------------------------------------
r.fund <- rets_d[[1]]
colnames(r.fund)<-names(rets_d)[1]
r.style <- merge.xts(rets_d[[10]],rets_d[[11]],rets_d[[13]],rets_d[[14]],rets_d[[23]],rets_d[[15]],rets_d[[16]])
colnames(r.style)<-names(rets_d)[c(10,11,13,14,23,15,16)]
RBSA_1 <- RBSA(r.fund,r.style)
print(RBSA_1)

## ----RBSA_rolling window-------------------------------------------------
RBSA_window<-RBSA_rolling(r.fund,r.style,method="constrained", width = 63)
head(RBSA_window)
autoplot(RBSA_window, main = "RBSA for FNDB")

## ---- fig.show='hold'----------------------------------------------------
plot(1:10)
plot(10:1)

## ---- echo=FALSE, results='asis'-----------------------------------------
knitr::kable(head(mtcars, 10))

